#!/bin/sh
# Check if dialog is installed, if not install it
if ! command -v dialog >/dev/null 2>&1; then
    echo "dialog is not installed. Installing..."
#    if command -v sudo >/dev/null 2>&1; then
        sudo apt-get update && sudo apt-get install -y dialog
        exit 1
    else
#        echo "Error: sudo not found. Please install 'dialog' manually."
            echo ""
#        exit 1
#    fi
fi

    bash ./game/script/set_0_.sh
main_menu() {

    bash ./game/script/0killler.sh

    # Array of filenames
    filenames="game_info.0hl
game_info.0hls
game_info.1br
game_info.2bg
game_info.3bgg
game_info.3bs
game_info.3cs
game_info.4cs
game_info.5cs
game_info.6cz
game_info.7cr
game_info.8dsh
game_info.8dst
game_info.91ind
game_info.91inv
game_info.92ns
game_info.92of
game_info.92ofc
game_info.93par
game_info.93pov
game_info.93res
game_info.93ric
game_info.94spc
game_info.94tfc
game_info.94tod
game_info.9ech
game_info.9exp
game_info.9fi
game_info.9fm
do_not_run_this
game_info.2bg_c
game_info.3bgg_c
game_info.4cs_c
game_info.5cs_c
game_info.6cz_c
game_info.8dsh_c
game_info.8dst_c
game_info.92ns_c
game_info.92ofc_c
game_info.93ric_c
game_info.94spc_c
game_info.94tfc_c
game_info.94tod_c
game_info.9fm_c"

    # Array of descriptions
    descriptions="HL Collection Half-Life
HL Collection Half-Life-safe mode
HL Collection Before
HL Collection BattleGrounds 1.01f
HL Collection BattleGrounds 1.2.1
HL Collection HL blue shift
HL Collection Caged CGS
HL Collection Counter strike 7.1
HL Collection Counter strike 1.6
HL Collection Counter strike CZ
HL Collection Counter strike CZ DS
HL Collection DoD Shrikebot 1.6
HL Collection DoD Sturmbot 1.6
HL Collection HL Induction
HL Collection HL Invasion
HL Collection NATURAL SELECTION Rcbot
HL Collection HL OpposingForce
HL Collection HL OpposingForce CTF
HL Collection HL Paranoia
HL Collection HL Point of view
HL Collection HL Restored
HL Collection HL Ricochet
HL Collection HL Specialists
HL Collection HL Team Fortress
HL Collection Tour of duty 1.3
HL Collection HL Echo
HL Collection HL Experiment 1.0
HL Collection HL Field Intensity
HL Collection FireArms 1.3
----------------------------------
Connect to BattleGrounds 1.01f
Connect to BattleGrounds 1.2.1
Connect to Counter strike 7.1
Connect to Counter strike 1.6
Connect to Counter strike CZ
Connect to DoD Shrikebot 1.6
Connect to DoD Sturmbot 1.6
Connect to NS Rcbot
Connect to HL OpposingForce
Connect to HL OpposingForce CTF
Connect to HL Ricochet
Connect to HL Specialists
Connect to HL Team Fortress
Connect to Tour of duty 1.3
Connect to FireArms 1.3"

    # Create menu options
    i=0
    options=""
    while [ $i -lt $(echo "$filenames" | wc -l) ]; do
        filename=$(echo "$filenames" | sed -n "$((i + 1))p")
        description=$(echo "$descriptions" | sed -n "$((i + 1))p")
        options="$options $i \"$description\""
        i=$((i + 1))
    done

    # Show the dialog menu
    choice=$(eval "dialog --cancel-label 'Quit' --menu 'Choose a game' 20 60 15 $options 3>&1 1>&2 2>&3 3>&-")
    clear

    if [ -n "$choice" ]; then
        chosen_filename=$(echo "$filenames" | sed -n "$((choice + 1))p")
        echo "You chose: $chosen_filename"

        cd game/game_info || exit
        rm -f game_info.txt
        cp "$chosen_filename" game_info.txt
        cd ../..

chmod -R 0700 game
export LANG=pl_PL.UTF-8

export QUIET_MODE=1
#export XEPHYR_SIZE=1920x1280
#export XEPHYR_SIZE=0
export DISABLE_NET=0

cd game || exit
./start.sh &
cd ..

echo "Waiting for hl.exe to finish..."

# Wait until hl.exe appears, then wait until it disappears
while ! pgrep -i hl.exe >/dev/null; do
    sleep 1
done

while pgrep -i hl.exe >/dev/null; do
    sleep 2
done

echo "hl.exe finished. Cleaning up Wine processes..."
killall -q wineserver explorer.exe services.exe conhost.exe svchost.exe 2>/dev/null
pkill -9 winedevice.exe
pkill -9 plugplay.exe
pkill -9 winedevice.exe
pkill -9 tabtip.exe
pkill -9 rpcss.exe
pkill -9 cmd.exe






    else
        echo "No game selected. Exiting."
        bash ./game/script/set.sh
        exit 0
    fi
}

# Loop menu forever until user cancels
while true; do
    main_menu
done


