ln -s "./game/game_info/data/Half-Life/name.txt" name.txt
ln -s "./game/game_info/data/Half-Life/server.txt" server.txt
ln -s "./game/game_info/data/Half-Life/parameters.txt" parameters.txt
echo please edit name.txt so that it contains your desired name in the game
echo please edit server.txt so that it contains ip of your friend which you want to connect to
echo when you are ready and files are saved please press enter to remove links...
read r
rm -f name.txt
rm -f server.txt
rm -f parameters.txt

